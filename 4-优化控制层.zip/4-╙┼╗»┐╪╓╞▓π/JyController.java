package qst.imnu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import qst.imnu.mapper.JyMapper;
import qst.imnu.pojo.Jy;
import qst.imnu.pojo.JyExample;
import qst.imnu.service.JyService;

import java.util.List;

@Controller
@RequestMapping("/jy")
public class JyController {
    @Autowired
    private JyMapper jm;
    @Autowired
    private JyService js;
    @RequestMapping("/jyli")
    @ResponseBody
    private List<Jy> getJylist(){
        JyExample je = new JyExample();
        List<Jy> jyli = jm.selectByExample(je);
        return jyli;
    }
    @PostMapping("/addjy")
    @ResponseBody
    public  int addjy(@RequestBody Jy j){
        int i = js.addJy(j);
        return  i ;
    }
}
