package qst.imnu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import qst.imnu.mapper.CourceMapper;
import qst.imnu.pojo.Cource;
import qst.imnu.pojo.CourceExample;
import qst.imnu.service.CourceService;

import java.util.List;
@Controller
@RequestMapping("/cou")
public class CourceController {
    @Autowired
    private CourceMapper cm;
    @Autowired
    private CourceService cs;
    @RequestMapping("/courceli")
    @ResponseBody
    public List<Cource> getcourcelist(int id)
    {
        CourceExample ce = new CourceExample();
        ce.createCriteria().andStunumberEqualTo(id);
        List<Cource> courceli = cm.selectByExample(ce);
        return  courceli;
    }
    @PostMapping("/insertcource")
    @ResponseBody
    public int  insertcource(@RequestBody Cource cour){
        int end = cs.insertcource(cour);
        return end;
    }
    @ResponseBody
    @GetMapping("/getallcource")
    public List<Cource> selectByAllCource(){
        List<Cource> allCource = cs.getAllCource();
        return allCource;
    }
    @GetMapping("/delectCource")
    @ResponseBody
    public int delectCourceByNo(int no){
        System.out.println("no"+no);
        int i = cs.deleteCourceByNo(no);
        return i;
    }
}
